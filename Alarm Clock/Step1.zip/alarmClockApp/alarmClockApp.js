import { LightningElement } from 'lwc';

export default class AlarmClockApp extends LightningElement {}